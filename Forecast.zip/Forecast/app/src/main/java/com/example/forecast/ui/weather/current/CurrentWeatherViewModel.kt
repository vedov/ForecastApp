package com.example.forecast.ui.weather.current

import androidx.lifecycle.ViewModel

class CurrentWeatherViewModel : ViewModel() {

}