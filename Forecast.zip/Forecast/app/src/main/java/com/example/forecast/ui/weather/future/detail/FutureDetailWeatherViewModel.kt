package com.example.forecast.ui.weather.future.detail

import androidx.lifecycle.ViewModel

class FutureDetailWeatherViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}