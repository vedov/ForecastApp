package com.example.forecast.data.db.entity


import com.google.gson.annotations.SerializedName

data class Weather(
    @SerializedName("description")
    val description: String,
    @SerializedName("icon")
    val icon: String,
    @SerializedName("id")
    val idWeather: Int,
    @SerializedName("main")
    val main: String
){
    constructor(): this("","",0,"")
}