package com.example.forecast.data.network

import okhttp3.Interceptor

interface ConnectivityInterceptor : Interceptor{
}